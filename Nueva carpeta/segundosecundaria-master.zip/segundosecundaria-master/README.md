# Producto Digital

Es una pagina web diseñada para la promoción y venta online de un producto digital, la cual, cuenta con un diseño responsive y un sistema de pago mediante Paypal.

>Este proyecto esta inspirado en el curso de desarrollo web profesional de Platzi.
